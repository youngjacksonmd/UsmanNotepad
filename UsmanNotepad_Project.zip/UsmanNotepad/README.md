# Usman Notepad (Android)

A tiny offline Android notepad app.

## Features
- Create notes
- Edit notes
- Delete notes
- Autosave when leaving the editor
- Local-only storage using SharedPreferences + JSON
- No account, no internet, no API key

## Build an APK
1. Install/open the latest stable Android Studio.
2. Open this `UsmanNotepad` folder.
3. Let Android Studio install/sync the required Android SDK and Gradle components.
4. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will appear under `app/build/outputs/apk/debug/`.

Project configuration used:
- Android Gradle Plugin 9.4.0
- compileSdk / targetSdk 37
- minSdk 23
- Java 17

## Privacy
All notes stay on the device inside the app's local preferences. The app requests no internet permission.
