package com.usman.notepad;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class EditorActivity extends Activity {
    private EditText titleInput;
    private EditText bodyInput;
    private long noteId;
    private boolean existing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        noteId = getIntent().getLongExtra("note_id", -1L);
        existing = noteId != -1L;
        if (!existing) noteId = System.currentTimeMillis();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView header = new TextView(this);
        header.setText(existing ? "Edit note" : "New note");
        header.setTextSize(24);
        header.setPadding(0, 0, 0, dp(12));
        root.addView(header);

        titleInput = new EditText(this);
        titleInput.setHint("Title");
        titleInput.setTextSize(20);
        titleInput.setSingleLine(true);
        root.addView(titleInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        bodyInput = new EditText(this);
        bodyInput.setHint("Write your note here…");
        bodyInput.setTextSize(17);
        bodyInput.setGravity(Gravity.TOP | Gravity.START);
        bodyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        bodyInput.setMinLines(12);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(bodyInput, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button save = new Button(this);
        save.setText("Save");
        actions.addView(save, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button delete = new Button(this);
        delete.setText("Delete");
        delete.setEnabled(existing);
        actions.addView(delete, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        root.addView(actions);
        setContentView(root);

        if (existing) {
            NoteStore.Note note = NoteStore.find(this, noteId);
            if (note != null) {
                titleInput.setText(note.title);
                bodyInput.setText(note.body);
            }
        }

        save.setOnClickListener(v -> saveAndClose());
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete this note?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    NoteStore.delete(this, noteId);
                    finish();
                }).show());
    }

    private void saveAndClose() {
        String title = titleInput.getText().toString();
        String body = bodyInput.getText().toString();
        if (title.trim().isEmpty() && body.trim().isEmpty()) {
            finish();
            return;
        }
        NoteStore.upsert(this, new NoteStore.Note(noteId, title, body, System.currentTimeMillis()));
        finish();
    }

    @Override
    public void onBackPressed() {
        saveAndClose();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
