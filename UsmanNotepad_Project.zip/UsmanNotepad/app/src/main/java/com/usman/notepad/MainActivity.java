package com.usman.notepad;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    private ListView listView;
    private TextView emptyView;
    private List<NoteStore.Note> notes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("Usman Notepad");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        Button add = new Button(this);
        add.setText("+ New note");
        root.addView(add, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("Tap a note to edit • Hold to delete");
        hint.setTextSize(13);
        hint.setPadding(0, dp(10), 0, dp(8));
        root.addView(hint);

        listView = new ListView(this);
        emptyView = new TextView(this);
        emptyView.setText("No notes yet. Create your first note ✍");
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setTextSize(16);

        root.addView(emptyView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(listView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);

        add.setOnClickListener(v -> startActivity(new Intent(this, EditorActivity.class)));
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent i = new Intent(this, EditorActivity.class);
            i.putExtra("note_id", notes.get(position).id);
            startActivity(i);
        });
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            NoteStore.Note note = notes.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Delete note?")
                    .setMessage(displayTitle(note))
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete", (d, w) -> {
                        NoteStore.delete(this, note.id);
                        refresh();
                    }).show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        notes = NoteStore.load(this);
        ArrayList<String> rows = new ArrayList<>();
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        for (NoteStore.Note n : notes) {
            String preview = n.body == null ? "" : n.body.trim().replace('\n', ' ');
            if (preview.length() > 70) preview = preview.substring(0, 70) + "…";
            rows.add(displayTitle(n) + "\n" + preview + "\n" + df.format(new Date(n.updatedAt)));
        }
        listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows));
        boolean isEmpty = notes.isEmpty();
        emptyView.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        listView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    private String displayTitle(NoteStore.Note n) {
        String t = n.title == null ? "" : n.title.trim();
        return t.isEmpty() ? "Untitled note" : t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
