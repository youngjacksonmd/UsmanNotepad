package com.usman.notepad;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public final class NoteStore {
    private static final String PREFS = "notepad_data";
    private static final String KEY = "notes";

    public static final class Note {
        public long id;
        public String title;
        public String body;
        public long updatedAt;

        public Note(long id, String title, String body, long updatedAt) {
            this.id = id;
            this.title = title;
            this.body = body;
            this.updatedAt = updatedAt;
        }
    }

    private NoteStore() {}

    public static List<Note> load(Context context) {
        List<Note> notes = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                notes.add(new Note(
                        o.optLong("id"),
                        o.optString("title"),
                        o.optString("body"),
                        o.optLong("updatedAt")
                ));
            }
        } catch (Exception ignored) {}
        Collections.sort(notes, new Comparator<Note>() {
            @Override
            public int compare(Note a, Note b) {
                return Long.compare(b.updatedAt, a.updatedAt);
            }
        });
        return notes;
    }

    public static void saveAll(Context context, List<Note> notes) {
        JSONArray array = new JSONArray();
        try {
            for (Note n : notes) {
                JSONObject o = new JSONObject();
                o.put("id", n.id);
                o.put("title", n.title);
                o.put("body", n.body);
                o.put("updatedAt", n.updatedAt);
                array.put(o);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, array.toString()).apply();
    }

    public static Note find(Context context, long id) {
        for (Note n : load(context)) if (n.id == id) return n;
        return null;
    }

    public static void upsert(Context context, Note note) {
        List<Note> notes = load(context);
        boolean replaced = false;
        for (int i = 0; i < notes.size(); i++) {
            if (notes.get(i).id == note.id) {
                notes.set(i, note);
                replaced = true;
                break;
            }
        }
        if (!replaced) notes.add(note);
        saveAll(context, notes);
    }

    public static void delete(Context context, long id) {
        List<Note> notes = load(context);
        Iterator<Note> it = notes.iterator();
        while (it.hasNext()) {
            if (it.next().id == id) it.remove();
        }
        saveAll(context, notes);
    }
}
