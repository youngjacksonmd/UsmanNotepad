@echo off
setlocal
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle assembleDebug
  goto done
)

echo Gradle was not found.
echo Open this folder in Android Studio, let it sync, then use:
echo Build ^> Build App Bundle(s) / APK(s) ^> Build APK(s)
echo.
echo The APK will be created under app\build\outputs\apk\debug\
:done
pause
